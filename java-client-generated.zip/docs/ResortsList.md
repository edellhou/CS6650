# ResortsList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resorts** | [**List&lt;ResortsListResorts&gt;**](ResortsListResorts.md) |  |  [optional]
