# ResortIDSeasonsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**year** | **String** | 4 character string specifying new season start year |  [optional]
