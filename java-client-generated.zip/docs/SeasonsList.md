# SeasonsList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**seasons** | **List&lt;String&gt;** |  |  [optional]
