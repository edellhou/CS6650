# SkierVertical

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resorts** | [**List&lt;SkierVerticalResorts&gt;**](SkierVerticalResorts.md) |  |  [optional]
